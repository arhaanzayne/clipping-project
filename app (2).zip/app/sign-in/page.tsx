import { redirect } from "next/navigation";

export default function Page() {
  redirect("https://free-impala-0.accounts.dev/sign-in");
}
