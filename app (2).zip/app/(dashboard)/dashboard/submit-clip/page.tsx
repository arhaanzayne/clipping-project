"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@clerk/nextjs";
import { supabase } from "@/lib/supabaseClient";

type VerifiedAccount = {
  id: string;
  user_id: string;
  platform: string;
  username: string;
  is_verified: boolean;
};

type Campaign = {
  id: string;
  name: string;
};

export default function SubmitClipPage() {
  const { userId, isLoaded } = useAuth();

  useEffect(() => {
  console.log("DEBUG → useAuth():", { userId, isLoaded });
}, [userId, isLoaded]);


  const [url, setUrl] = useState("");
  const [platform, setPlatform] = useState("");
  const [accounts, setAccounts] = useState<VerifiedAccount[]>([]);
  const [selectedAccount, setSelectedAccount] = useState("");
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [accountsLoading, setAccountsLoading] = useState(true);

  // For debugging if needed
  // useEffect(() => {
  //   console.log("SubmitClip auth:", { isLoaded, userId });
  // }, [isLoaded, userId]);

  // -----------------------------
  // FETCH VERIFIED ACCOUNTS (THIS USER ONLY)
  // -----------------------------
  useEffect(() => {
    // Wait until Clerk is loaded
    if (!isLoaded) return;

    // If user is not logged in, don't even try
    if (!userId) {
      setAccounts([]);
      setAccountsLoading(false);
      return;
    }

    const fetchAccounts = async () => {
      setAccountsLoading(true);
      const { data, error } = await supabase
        .from("user_verifications")
        .select("*")
        .eq("user_id", userId)
        .eq("is_verified", true);

      if (!error && data) {
        setAccounts(data as VerifiedAccount[]);
      } else {
        console.error("FETCH ACCOUNTS ERROR:", error);
        setAccounts([]);
      }
      setAccountsLoading(false);
    };

    fetchAccounts();
  }, [isLoaded, userId]);

  // -----------------------------
  // FETCH CAMPAIGNS (NO AUTH NEEDED)
  // -----------------------------
  useEffect(() => {
    const fetchCampaigns = async () => {
      const { data, error } = await supabase
        .from("campaigns")
        .select("id, name");

      if (!error && data) {
        setCampaigns(data as Campaign[]);
      } else {
        console.error("FETCH CAMPAIGNS ERROR:", error);
      }
    };

    fetchCampaigns();
  }, []);

  // -----------------------------
  // AUTO-DETECT PLATFORM
  // -----------------------------
  useEffect(() => {
    const lower = url.toLowerCase();

    if (lower.includes("instagram")) setPlatform("instagram");
    else if (lower.includes("tiktok")) setPlatform("tiktok");
    else if (lower.includes("youtube") || lower.includes("youtu.be"))
      setPlatform("youtube");
    else if (lower.includes("twitter") || lower.includes("x.com"))
      setPlatform("x");
    else setPlatform("");
  }, [url]);

  // -----------------------------
  // SUBMIT CLIP
  // -----------------------------
  const submitClip = async () => {
    setLoading(true);
    setMessage("");

    // extra safety: block submit if not logged in
    if (!userId) {
      setLoading(false);
      setMessage("❌ You must be logged in to submit clips.");
      return;
    }

    try {
      const res = await fetch("/api/submit-clip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clip_url: url,
          verified_account_id: selectedAccount,
          campaign_id: selectedCampaign,
          platform,
          user_id: userId, // still sending it along
        }),
      });

      const result = await res.json();

      if (!res.ok) {
        setMessage("❌ " + (result.error || "Something went wrong"));
      } else {
        setMessage("✅ Clip submitted successfully!");
        setUrl("");
        setSelectedAccount("");
        setSelectedCampaign("");
      }
    } catch (err) {
      console.error("SUBMIT CLIP ERROR:", err);
      setMessage("❌ Unexpected error while submitting clip.");
    } finally {
      setLoading(false);
    }
  };

  // -----------------------------
  // UI
  // -----------------------------
  return (
    <div className="p-6 text-white">
      <h1 className="text-2xl font-bold mb-6">Submit a Clip</h1>

      {/* AUTH STATUS MESSAGE (LIKE A SOFT VERSION OF YOUR OLD GUARD) */}
      {!isLoaded ? (
        <p className="mb-4">Loading your account…</p>
      ) : !userId ? (
        <p className="mb-4 text-red-400">
          You are not logged in. Please sign in before submitting clips.
        </p>
      ) : null}

      {/* URL */}
      <div className="mb-4">
        <label className="block mb-2">Clip URL</label>
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="Paste your clip URL…"
          className="w-full p-3 rounded bg-gray-800 border border-gray-700"
        />
      </div>

      {platform && (
        <p className="mb-4 text-green-400">Detected platform: {platform}</p>
      )}

      {/* CAMPAIGN */}
      <div className="mb-4">
        <label className="block mb-2">Select Campaign</label>
        <select
          value={selectedCampaign}
          onChange={(e) => setSelectedCampaign(e.target.value)}
          className="w-full p-3 rounded bg-gray-800 border border-gray-700"
        >
          <option value="">-- Choose Campaign --</option>
          {campaigns.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* VERIFIED ACCOUNT */}
      <div className="mb-4">
        <label className="block mb-2">Select Verified Account</label>
        {accountsLoading ? (
          <p>Loading your verified accounts…</p>
        ) : accounts.length === 0 ? (
          <p className="text-sm text-gray-400">
            No verified accounts found. Please verify at least one account
            first.
          </p>
        ) : (
          <select
            value={selectedAccount}
            onChange={(e) => setSelectedAccount(e.target.value)}
            className="w-full p-3 rounded bg-gray-800 border border-gray-700"
          >
            <option value="">-- Choose Account --</option>
            {accounts.map((acc) => (
              <option key={acc.id} value={acc.id}>
                {acc.username} ({acc.platform})
              </option>
            ))}
          </select>
        )}
      </div>

      {/* SUBMIT BTN */}
      <button
        onClick={submitClip}
        disabled={
          !url ||
          !selectedAccount ||
          !selectedCampaign ||
          !platform ||
          loading ||
          !userId // also prevent clicks if logged out
        }
        className="px-4 py-2 bg-blue-600 rounded disabled:opacity-50"
      >
        {loading ? "Submitting…" : "Submit Clip"}
      </button>

      {message && <p className="mt-4">{message}</p>}
    </div>
  );
}
