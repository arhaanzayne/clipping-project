import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function GET() {
  try {
    const { data, error } = await supabaseAdmin
      .from("clips")
      .select(
        "id, user_id, campaign_id, platform, account_username, clip_url, status, earnings, created_at"
      )
      .order("created_at", { ascending: false });

    if (error) {
      console.error("ADMIN GET CLIPS ERROR:", error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ clips: data ?? [] });
  } catch (err: any) {
    console.error("ADMIN GET CLIPS ROUTE ERROR:", err);
    return NextResponse.json(
      { error: err?.message ?? "Server error" },
      { status: 500 }
    );
  }
}
