import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function detectPlatform(url: string) {
  const lower = url.toLowerCase();
  if (lower.includes("instagram")) return "instagram";
  if (lower.includes("tiktok")) return "tiktok";
  if (lower.includes("youtube") || lower.includes("youtu.be")) return "youtube";
  if (lower.includes("twitter") || lower.includes("x.com")) return "x";
  return "unknown";
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    console.log("submit-clip BODY:", body);

    const clip_url = body.clip_url;
    const verified_account_id = body.verified_account_id;
    const campaign_id = body.campaign_id;
    const campaign_name = body.campaign_name;
    const user_id = body.user_id;       // <-- trust frontend
    const user_email = body.user_email; // <-- trust frontend
    const platform =
      body.platform || (clip_url ? detectPlatform(clip_url) : "unknown");

    // -------------------------------------------------------
    // BASIC VALIDATION (no Clerk auth needed anymore)
    // -------------------------------------------------------
    if (!user_id) {
      return NextResponse.json(
        { error: "Missing user_id. Please log in again." },
        { status: 401 }
      );
    }

    if (!clip_url || !verified_account_id || !campaign_id || !campaign_name) {
      return NextResponse.json(
        { error: "Missing fields." },
        { status: 400 }
      );
    }

    // -------------------------------------------------------
    // VERIFY THAT VERIFIED ACCOUNT BELONGS TO THIS USER
    // -------------------------------------------------------
    const { data: accData, error: accError } = await supabaseAdmin
      .from("user_verifications")
      .select("username, platform")
      .eq("id", verified_account_id)
      .eq("user_id", user_id)
      .single();

    if (accError || !accData) {
      console.error("ACCOUNT LOOKUP ERROR:", accError);
      return NextResponse.json(
        { error: "Verified account not found." },
        { status: 400 }
      );
    }

    // -------------------------------------------------------
    // INSERT CLIP
    // -------------------------------------------------------
    const { error: insertError } = await supabaseAdmin
      .from("clips")
      .insert([
        {
          campaign_id,
          campaign_name,
          user_id,
          user_email,
          platform,
          verified_account_id,
          account_username: accData.username,
          clip_url,
          status: "pending",
          earnings: 0,
        },
      ]);

    if (insertError) {
      console.error("CLIP INSERT ERROR:", insertError);
      return NextResponse.json(
        { error: insertError.message },
        { status: 500 }
      );
    }

    return NextResponse.json({ success: true }, { status: 200 });

  } catch (err: any) {
    console.error("submit-clip API ERROR:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 }
    );
  }
}
